#!/system/bin/sh
# Neon Fox Sound Pack: replaces existing UI sounds, adds new notification/ringtone/alarm tones.
ROOT="${ROOT:-}"
ui_print "==========================================="
ui_print "  Neon Fox Sound Pack"
ui_print "==========================================="
N=0
for REL in media/audio/ui product/media/audio/ui system_ext/media/audio/ui vendor/media/audio/ui; do
  for F in ChargingStarted WirelessChargingStarted Unlock Lock LowBattery Effect_Tick KeypressStandard KeypressSpacebar KeypressDelete KeypressReturn KeypressInvalid; do
    if [ -f "$ROOT/system/$REL/$F.ogg" ]; then
      mkdir -p "$MODPATH/system/$REL"
      cp -f "$MODPATH/sounds/ui/$F.ogg" "$MODPATH/system/$REL/$F.ogg"
      ui_print "- Replaced /system/$REL/$F.ogg"
      N=$((N+1))
    fi
  done
done
[ "$N" = 0 ] && ui_print "- No matching UI sound files on this ROM (tones will still be added)"
for D in notifications ringtones alarms; do
  mkdir -p "$MODPATH/system/media/audio/$D"
  cp -f "$MODPATH/sounds/$D/"*.ogg "$MODPATH/system/media/audio/$D/"
done
ui_print "- Added tones: NeonFox_Ping, NeonFox_Glitch, NeonFox_Pulse, NeonFox_Ringtone, NeonFox_Alarm"
rm -rf "$MODPATH/sounds"
set_perm_recursive "$MODPATH/system" 0 0 0755 0644 u:object_r:system_file:s0
ui_print "- Reboot. Pick the tones in Settings > Sound."
