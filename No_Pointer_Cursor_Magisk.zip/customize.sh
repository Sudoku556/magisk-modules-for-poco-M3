#!/system/bin/sh
# Excludes the phantom "vitural-sar" input device (classified as MOUSE) from Android's input system.
ROOT="${ROOT:-}"
NAME="vitural-sar"
SRC="$ROOT/system/etc/excluded-input-devices.xml"
DST="$MODPATH/system/etc/excluded-input-devices.xml"
mkdir -p "$MODPATH/system/etc"
ui_print "- Excluding input device: $NAME"
if [ -f "$SRC" ] && grep -q '</devices>' "$SRC"; then
  if grep -q "name=\"$NAME\"" "$SRC"; then
    ui_print "- Already excluded by the ROM, nothing to add"
  fi
  awk -v n="$NAME" '/<\/devices>/{print "    <device name=\"" n "\" />"} {print}' "$SRC" > "$DST"
  ui_print "- Added to the ROM's existing list"
else
  cat > "$DST" <<X
<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<devices>
    <device name="$NAME" />
</devices>
X
  ui_print "- Created a new exclusion list"
fi
set_perm_recursive "$MODPATH/system" 0 0 0755 0644 u:object_r:system_file:s0
ui_print "- Reboot, then check: dumpsys input | grep -E 'Device|Sources'"
